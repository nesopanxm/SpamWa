`
Bara ( Creator )
Tama ( Friend )
zynxzo ( Friend )
Kiur ( Friend )`
